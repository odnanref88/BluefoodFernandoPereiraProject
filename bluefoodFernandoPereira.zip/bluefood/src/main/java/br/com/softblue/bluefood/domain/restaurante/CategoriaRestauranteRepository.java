package br.com.softblue.bluefood.domain.restaurante;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRestauranteRepository extends JpaRepository<CategoriaRestaurante, Integer> {
       
	
	 
}
